#ifndef A7F631C8_A804_4C43_8794_D51DEA297DEC
#define A7F631C8_A804_4C43_8794_D51DEA297DEC

#include "process.h"

Process* read_processes_from_file(const char* filename, int* count);

#endif /* A7F631C8_A804_4C43_8794_D51DEA297DEC */
