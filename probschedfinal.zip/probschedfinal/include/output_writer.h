#ifndef D4FAC80D_3DB9_4523_B111_176440B4DD1F
#define D4FAC80D_3DB9_4523_B111_176440B4DD1F

#include "process.h"

void write_output(Process* processes, int n, const char* algoritmo);

#endif /* D4FAC80D_3DB9_4523_B111_176440B4DD1F */
