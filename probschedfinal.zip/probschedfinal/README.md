# ProbSched — Simulador de Escalonamento Probabilístico

## 🎯 Objetivo

Simular diferentes algoritmos de escalonamento de processos em C (Roun Robin, Simplest Job First, First Come First Served), com chegada e execução baseadas em distribuições probabilísticas.

---

## 👨‍💻 Autores

- João Grilo (a49776)
- Tiago Deusdado (a50123)
- Tiago Ramos (a47883)
- Ricardo Matias (a46586)

---

## 🛠️ Compilação

```bash
make

Para executar:
make run
