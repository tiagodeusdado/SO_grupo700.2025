#ifndef B9E9BB2F_2DF6_4056_B635_4F0B95A6CBF6
#define B9E9BB2F_2DF6_4056_B635_4F0B95A6CBF6

#include <stdlib.h>
#include <stdio.h>
#include "../include/process.h"



Process* generate_processes(int count);

#endif /* B9E9BB2F_2DF6_4056_B635_4F0B95A6CBF6 */
